package taskOn29;

import java.util.Scanner;

public class Pattern {
	Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		new Pattern().getInput();
	}

	private void getInput() {
		System.out.println("Enter String:");
		String string = input.nextLine();
		System.out.println("Enter rows : ");
		int row = input.nextInt();
		patternize(string, row);
	}

	private void patternize(String string, int row) {
		char array[][] = new char[row][string.length()];
		int index;
		for (int i = 0; i < row; i++) {
			index = 0;
			for (int j = 0; j < array[0].length;) {
				if (i == 0 || i == row - 1) {
					array[i][j] = string.charAt(index);
//					j += (row - 1);
					index = (row + (row - 2));
					j=index;
				} else {
					j++;
				}
//				index = (row + (row - 2));
//				j=index;
			}
		}
		printArray(array);
	}

	private void printArray(char[][] array) {
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[0].length; j++) {
				if (array[i][j] != '\0')
					System.out.print(" ");
				else
					System.out.print(array[i][j]);
			}
			System.out.println();
		}
	}

}
