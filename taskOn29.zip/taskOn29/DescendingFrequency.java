package taskOn29;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;

public class DescendingFrequency {
	Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		new DescendingFrequency().getInput();
	}

	private void getInput() {
		System.out.println("Enter n:");
		int n = input.nextInt();
		int[] array = new int[n];
		System.out.println("Enter array elements : ");
		for (int i = 0; i < n; i++) {
			array[i] = input.nextInt();
		}
		getDescendingValue(n, array);
	}

	private void getDescendingValue(int n, int[] array) {
		HashMap<Integer, Integer> map = new LinkedHashMap<>();
		int num, freq = 0;
		List<Entry<Integer, Integer>> listValue = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			num = array[i];
			if (map.containsKey(num)) {
				freq = map.get(num) + 1;
				map.put(num, freq);
			} else {
				freq = 1;
				map.put(num, freq);
			}
		}
		listValue.addAll(map.entrySet());
		Collections.sort(listValue, new Comparator<Entry<Integer, Integer>>() {
			@Override
			public int compare(Entry<Integer, Integer> l1, Entry<Integer, Integer> l2) {
				return l2.getValue().compareTo(l1.getValue());
			}
		});
		System.out.println(listValue);
		int key, value;
		for (int i = 0; i < listValue.size(); i++) {
			key = listValue.get(i).getKey();
			value = listValue.get(i).getValue();
			while (value > 0) {
				System.out.print(key);
				value--;
			}
		}
	}
}
