package taskOn29;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class SendMessage {
	Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		new SendMessage().getInput();
	}

	private void getInput() {
		System.out.println("Enter Number of Packets : ");
		int n = input.nextInt();
		String[] packet = new String[n];
		input.nextLine();
		for (int i = 0; i < n; i++) {
			System.out.print("P" + (i + 1) + " : ");
			packet[i] = input.nextLine();
		}
		orderPacket(n, packet);
	}

	private void orderPacket(int n, String[] packet) {
		HashMap<Integer, String> buffer = new HashMap<>();
		HashMap<Integer, String> correct = new HashMap<>();
		String string, number;
		int num;
		List<Integer> list = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			string = "";
			number = "";
			num = 0;
			char[] message = packet[i].toCharArray();
			for (int j = 1; j < message.length - 1; j++) {
				if (j == 1) {
					number = number + message[j];
					while (message[++j] != '-') {
						number = number + message[j];
					}
				} else {
					string = string + message[j];
				}
			}
			num = Integer.valueOf(number);
			if (num != (i + 1)) {
				buffer.put(num, string);
			} else {
				correct.put(num, string);
			}
		}
		list.addAll(buffer.keySet());
		getMessage(n, packet, buffer, correct);
		getMax(packet);
	}

	private void getMessage(int n, String[] packet, HashMap<Integer, String> buffer, HashMap<Integer, String> correct) {
		String message = "";
		if (buffer.size() == 0) {
			System.out.println("\nMessages are ordered already!\n");
		}
		for (int i = 1; i <= n; i++) {
			if (buffer.containsKey(i)) {
				message = message + buffer.get(i);
			} else if (correct.containsKey(i))
				message = message + correct.get(i);
		}
		System.out.println("Message sent : " + message);
	}

	private void getMax(String[] packet) {
		int max = packet[0].length() - 2, index = 0;
		for (int i = 1; i < packet.length; i++) {
			int each = packet[i].length() - 2;
			if (max <= each) {
				index = i;
				max = each;
			}
		}
		System.out.println(
				"\nbuffered packet with maximum size : " + (packet[index].length() - 2) + " - for " + packet[index]);
	}
}
