package taskOn29;

import java.util.Arrays;
import java.util.Scanner;

public class SortArray {
	private Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		new SortArray().getInput();
	}

	private void getInput() {
		System.out.println("Enter n:");
		int n = input.nextInt();
		int[] array = new int[n];
		System.out.println("Enter array elements : ");
		for (int i = 0; i < n; i++) {
			array[i] = input.nextInt();
		}
		doSort(n, array);
	}

	private void doSort(int n, int[] array) {
		int num, index, count;
		for (int i = 0; i < n;) {
			num = array[i];
			index = i;
			count = 0;
			for (int j = i + 2; j < n; j = j + 2) {
				if (i % 2 == 0) {
					if (num > array[j]) {
						array[index] = array[j];
						index += 2;
						array[j] = num;
						count++;
					}
				} else {
					if (num < array[j]) {
						array[index] = array[j];
						index += 2;
						array[j] = num;
						count++;
					}
				}
			}
			if (count == 0) {
				i++;
			}
		}
		System.out.println(Arrays.toString(array));
	}
}
